# Spotify-Clone-App
This repository hosts my very first web development project, a straightforward Spotify clone built using HTML, CSS, and JavaScript. While this app is intentionally basic, it represents the beginning of my web development journey. It's a starting point for web development enthusiasts to build upon and expand their skills. 
