console.log("Welcome to Spotify");

//Initialise the variables
let songIndex= 0;
let audioElement = new Audio('1.song.mp3');
let masterPlay = dpcument.getElementaryById('masterPlay');
let myProgressBar = document.getElementById('myProgressBar');
let gif = document.getElementById('gif');

let songs = [
   {songName: "Copines", filepath: "song/1.song.mp3", coverpath: "covers/1.jpg"},
   {songName: "Copines", filepath: "song/1.song.mp3", coverpath: "covers/1.jpg"},
]

// audioElement.play();

//Handle play/pause click
masterPlay.addEventListener('click',()=>{
    if(audioElement.paused || audioElement.currentTime<=0){
        audioElement.play(); 
       masterPlay.classList.remove('fa-circle-play');
       masterPlay.classList.add('fa-circle-pause');
       gif.style.opacity = 1;
       

    }
    else{

        audioElement.pause(); 
        masterPlay.classList.remove('fa-circle-pause');
        masterPlay.classList.add('fa-circle-play');
    }
      

}) 

//Listen to Events
 myProgressBar.addEventListener('timeupdate', ()=>{
console.log('timeupdate');
//update Seekbar

 })